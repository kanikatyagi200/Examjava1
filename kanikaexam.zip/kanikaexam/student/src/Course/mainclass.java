package Course;

public class mainclass {

	
	public static void main(String[]args) {
		
		course c=new course();
		course c1=new course(101,"Neet");
		System.out.println(c1);
		
		
		//function overloading
		
		c.Totalcourses(5000.0);
		int result = c.Totalcourses(60);
		System.out.println("Total number of courses : "+ result);
		crashcourse c2= new crashcourse("Gate",2);
		int parts = c2.courseparts(4);
		System.out.println("Total number of courses : "+ parts);
		
	}

	
}
