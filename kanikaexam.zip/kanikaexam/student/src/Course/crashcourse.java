package Course;

public class crashcourse extends course {
        String name;
        int duration;
        int fee;
        
        public crashcourse()
        {}
		 public crashcourse(String name, int duration) {
		 this.name = name;
		 this.duration = 12;
		 }
		
        
public String getName() {
			return name;
		}



		public void setName(String name) {
			this.name = name;
		}



		public int getDuration() {
			return duration;
		}



		public void setDuration(int duration) {
			this.duration = duration;
		}



		public int getFee() {
			return fee;
		}



		public void setFee(int fee) {
			this.fee = fee;
		}



@Override
		public String toString() {
			return "crashcourse [name=" + name + ", duration=" + duration + ", fee=" + fee + "]";
		}


@Override
public  int courseparts(int cp) {
	System.out.println("Inside crash course : "+ cp);
	return cp;
}
}
   
        
        
        
       

     