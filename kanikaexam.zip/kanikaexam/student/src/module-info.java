/**
 * 
 */
/**
 * @author U9GGAHU
 *
 */
module student {
}